package exam;
interface j1{
	void write();
}
interface j2{
	void help();
}
interface j3 extends j1,j2{
	void game();
}
class view{
	public void picture() {
		System.out.println("picturing");
	}
}
public class CaseI extends view implements j3{
	public void write() {
		System.out.println("writing");
	}
    public void help() {
    	System.out.println("helping");
    }
    public void game() {
    	System.out.println("gaming");
    }
    public void read() {
    	System.out.println("reading");
    }
	public static void main(String[] args) {
		caseI e=new caseI();
		e.write();
		e.help();
		e.game();
		e.read();
	}
}

